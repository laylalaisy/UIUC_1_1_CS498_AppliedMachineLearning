Run:

- Open each R file
- Set current_path as current working directory in line 8
- Run R file to get the result
