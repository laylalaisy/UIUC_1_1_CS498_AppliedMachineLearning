RUN:

- Open python file
- Download / install related libraby mentioned at the beginning python file
- Run python file
